package com.kazeik.doctor.doctorexam.bean;/**
 * 我的帐户帐单
 *
 * @author kazeik.chen , QQ:77132995,email:kazeik@163.com 2016 04 17 20:24
 */

import java.io.Serializable;
import java.util.List;

/**
 * 我的帐户帐单
 * @author kazeik.chen , QQ:77132995,email:kazeik@163.com 2016 04 17 20:24
 */

public class AccountBean implements Serializable{
//    {"re_st":"success","re_msg":{"detail_array":[],"balance":"1000.00","learn_card":""},"re_url":""}
    /**
     * re_st : success
     * re_msg : {"detail_array":[{"pay_type":"账户余额","in_out_amount":"支出","in_out_amount_st":"2","id":"111378","order_id":"1662706145336478895","amount":"100.00","order_time":"2016-01-21 16:26:30"},{"pay_type":"账户余额","in_out_amount":"存入","in_out_amount_st":"1","id":"111373","order_id":"16001000145258351266","amount":"100.00","order_time":"2016-01-14 18:44:00"}],"balance":"650.00","learn_card":{"useful_life":"2018-01-12","activation_date":"2016-01-14 18:44:00","card_num":"16001000145258351266","activation_ip":"180.173.28.85","initial_limit":"100"}}
     * re_url :
     */

    public String re_st;
    /**
     * detail_array : [{"pay_type":"账户余额","in_out_amount":"支出","in_out_amount_st":"2","id":"111378","order_id":"1662706145336478895","amount":"100.00","order_time":"2016-01-21 16:26:30"},{"pay_type":"账户余额","in_out_amount":"存入","in_out_amount_st":"1","id":"111373","order_id":"16001000145258351266","amount":"100.00","order_time":"2016-01-14 18:44:00"}]
     * balance : 650.00
     * learn_card : {"useful_life":"2018-01-12","activation_date":"2016-01-14 18:44:00","card_num":"16001000145258351266","activation_ip":"180.173.28.85","initial_limit":"100"}
     */

    public ReMsgEntity re_msg;
    public String re_url;

    public static class ReMsgEntity {
        public String balance;
        /**
         * useful_life : 2018-01-12
         * activation_date : 2016-01-14 18:44:00
         * card_num : 16001000145258351266
         * activation_ip : 180.173.28.85
         * initial_limit : 100
         */

        public List<LearnCardEntity> learn_card;
        /**
         * pay_type : 账户余额
         * in_out_amount : 支出
         * in_out_amount_st : 2
         * id : 111378
         * order_id : 1662706145336478895
         * amount : 100.00
         * order_time : 2016-01-21 16:26:30
         */

        public List<DetailArrayEntity> detail_array;

        public static class LearnCardEntity {
            public String useful_life;
            public String activation_date;
            public String card_num;
            public String activation_ip;
            public String initial_limit;
        }

        public static class DetailArrayEntity {
            public String pay_type;
            public String in_out_amount;
            public int in_out_amount_st;
            public String id;
            public String order_id;
            public String amount;
            public String order_time;
        }
    }
}
