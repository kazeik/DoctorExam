package com.kazeik.doctor.doctorexam.bean;

/**
 * Created by kazeik.chen on 2016/5/9 0009 11:09.
 * email:kazeik@163.com ,QQ:77132995
 */
public class BaseBean {

    /**
     * re_st : success
     * re_msg : 密码已修改成功，请登录。
     * re_url :
     */

    public String re_st;
    public String re_msg;
    public String re_url;
}
