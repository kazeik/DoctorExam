package com.kazeik.doctor.doctorexam.activity;

import android.app.Dialog;
import android.content.Intent;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.kazeik.doctor.doctorexam.BaseActivity;
import com.kazeik.doctor.doctorexam.R;
import com.kazeik.doctor.doctorexam.adapter.MockBodyAdapter;
import com.kazeik.doctor.doctorexam.bean.MockExamBean;
import com.kazeik.doctor.doctorexam.utils.ApiUtils;
import com.kazeik.doctor.doctorexam.utils.AppUtils;
import com.lidroid.xutils.http.RequestParams;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.Map;

import butterknife.Bind;
import butterknife.OnClick;

public class MockInfoActivity extends BaseActivity implements View.OnClickListener {

    String id;
    String code;
    @Bind(R.id.tv_titleName)
    TextView tvTitleName;
    @Bind(R.id.tv_left)
    TextView tvLeft;
    @Bind(R.id.tv_right)
    TextView tvRight;
    @Bind(R.id.ls_listView)
    ListView lsListView;

    MockBodyAdapter bodyAdapter;
    MockExamBean examBean;

    boolean checkAnswer;

    String fileBody;


    @Override
    public int initLayout() {
        return R.layout.activity_lesson;
    }

    @Override
    public void initData() {
        id = getIntent().getStringExtra("id");
        code = getIntent().getStringExtra("code");
        checkAnswer = getIntent().getBooleanExtra("check", false);
        fileBody = getIntent().getStringExtra("body");
    }

    @Override
    public void initWeight() {
        tvTitleName.setText(R.string.mock);
        tvLeft.setText(R.string.back);
        tvRight.setText(R.string.answer_car);
        tvLeft.setVisibility(View.VISIBLE);
        tvRight.setVisibility(View.VISIBLE);

        bodyAdapter = new MockBodyAdapter(this);
        if (!checkAnswer) {
            View view = LayoutInflater.from(this).inflate(R.layout.layout_footview, null);
            view.findViewById(R.id.btn_answer).setOnClickListener(this);
            lsListView.addFooterView(view);
        } else {
            bodyAdapter.setCheckAnswer(true);
        }
        lsListView.setAdapter(bodyAdapter);

        if (TextUtils.isEmpty(fileBody)) {
            RequestParams params = getParams();
            params.addBodyParameter("paper_id", id);
            params.addBodyParameter("encryption", id + "_" + code);
            requestNetData(params, ApiUtils.mockBody);
        } else {
            parserExam(fileBody);
        }

    }


    private void parserExam(String value) {
        examBean = new MockExamBean();
        examBean.re_msg = new MockExamBean.ReMsgEntity();
        try {
            JSONObject object = new JSONObject(value);
            JSONObject msgObj = object.optJSONObject("re_msg");
            examBean.re_msg.pid = msgObj.optInt("pid");
            JSONObject paperInfoObj = msgObj.optJSONObject("paper_info");
            examBean.re_msg.paper_info = gson.fromJson(paperInfoObj.toString(), MockExamBean.PaperInfo.class);
            //---------------------
            JSONObject cateObject = msgObj.optJSONObject("category_arr");
            Iterator iterator = cateObject.keys();
            while (iterator.hasNext()) {
                String key = iterator.next().toString();
                String va = cateObject.optString(key);
                examBean.re_msg.category.add(va);
            }
            //---------------------
            JSONObject proObject = msgObj.optJSONObject("profession_arr");
            Iterator proIter = proObject.keys();
            while (proIter.hasNext()) {
                String key = proIter.next().toString();
                String va = proObject.optString(key);
                examBean.re_msg.profession_arr.put(va, key);
            }
            //----------------------
            JSONObject questionObject = msgObj.optJSONObject("question");
            Iterator questIter = questionObject.keys();
            while (questIter.hasNext()) {
                String tempKey = questIter.next().toString();
                JSONObject s_62 = questionObject.optJSONObject(tempKey);
                Iterator iter_62 = s_62.keys();
                while (iter_62.hasNext()) {
                    String k_501 = iter_62.next().toString();
                    JSONObject s_501 = s_62.optJSONObject(k_501);

                    MockExamBean.Entity501 entity501 = gson.fromJson(s_501.toString(), MockExamBean.Entity501.class);
                    examBean.re_msg.entity501.add(entity501);
                }
            }
            //-----------------------
        } catch (JSONException e) {
            e.printStackTrace();
        }
        bodyAdapter.setData(examBean.re_msg.entity501);
    }

    @Override
    public void onNetSuccess(String tag, String value) {
        if (tag.equals(ApiUtils.mockBody)) {
            parserExam(value);
        } else if (tag.equals(ApiUtils.submitAnswer)) {
            try {
                JSONObject obj = new JSONObject(value);
                String flag = obj.optString("re_st");
                if (flag.equals("success")) {
                    AppUtils.showToast(this, obj.optString("re_msg"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    @OnClick({R.id.tv_left, R.id.tv_right})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_left:
                finish();
                break;
            case R.id.tv_right:
                Intent intt = new Intent(this, ExamIndexActivity.class);
                intt.putExtra("len", examBean.re_msg.entity501.size());
                intt.putExtra("choice", bodyAdapter.getChoiceHash());
                startOtherViewForCode(intt, 99);
                break;
            case R.id.btn_answer:
                if(bodyAdapter.getAnswHash().size() < examBean.re_msg.entity501.size()){
                    AppUtils.showToast(this,"您还有未答完的题目");
                    return;
                }
                showAlert();
                break;
        }
    }

    private void submitAnswer() {
        StringBuffer sb = new StringBuffer();
        Map<String, String> answerMap = bodyAdapter.getAnswHash();
        Iterator iterator = answerMap.entrySet().iterator();
        sb.append("[");
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            String answ = "a[\"" + entry.getKey().toString() + "\"][u]=\"" + entry.getValue().toString() + "\"";
            sb.append(answ);
            sb.append(",");
        }
        String temp = sb.toString();
        temp = temp.substring(0, temp.length() - 1);
        sb.append(temp);
        sb.append("]");
        String val = sb.toString();
        AppUtils.logs(getClass(), val);
        submitAnswer(val);
    }

    private void showAlert() {
        final Dialog dialog = new Dialog(this, R.style.dialog);
        dialog.setContentView(R.layout.follow_pracitce_dialog);
        TextView ldms_btn = (TextView) dialog.findViewById(R.id.tv_leftText);
        TextView vip_btn = (TextView) dialog.findViewById(R.id.tv_rightText);
        TextView tv_content = (TextView) dialog.findViewById(R.id.tv_content);
        TextView tv_title = (TextView) dialog.findViewById(R.id.tv_dialog_title);
        tv_title.setText("温馨提示");
        tv_content.setText("你确定要交卷吗？");
        ldms_btn.setText("取消");
        vip_btn.setText("交卷");
        ldms_btn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                dialog.dismiss();
                dialog.cancel();
            }
        });
        vip_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                dialog.cancel();
                submitAnswer();
            }
        });
        dialog.show();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (data != null && requestCode == 99) {
            int index = data.getIntExtra("index", 0);
            lsListView.setSelection(index);
        }
    }

    private void submitAnswer(String answer) {
        RequestParams params = getParams();
        params.addBodyParameter("encryption", id + "_" + code);
        params.addBodyParameter("a", answer);
        requestNetData(params, ApiUtils.submitAnswer);
    }
}
