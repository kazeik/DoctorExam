package com.kazeik.doctor.doctorexam.bean;

/**
 * Created by kazeik.chen on 2016/4/21 0021 16:03.
 * email:kazeik@163.com ,QQ:77132995
 */
public class ChatItemBean {

    /**
     * id : 134
     * fromid : 126
     * toid : 56199
     * messages : hello
     * is_read : 1
     * mtime : 2016-03-08 17:00:26
     */

    public int id;
    public String fromid;
    public String toid;
    public String messages;
    public String is_read;
    public String mtime;

    public boolean send;
}
