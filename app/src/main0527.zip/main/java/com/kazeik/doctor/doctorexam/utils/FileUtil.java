//package com.kazeik.databaseslib.utils;
//
//
///**
// * Created by chenwei on 2015/6/16.
// */
//
//
//import java.io.File;
//import java.io.IOException;
//
//import android.os.Environment;
//import android.util.Log;
//
//public class FileUtil {
//    private static final String TAG = "FileUtil";
//
//
//}
