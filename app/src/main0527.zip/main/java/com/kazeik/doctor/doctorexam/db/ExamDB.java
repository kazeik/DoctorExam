package com.kazeik.doctor.doctorexam.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.TextUtils;

import com.kazeik.doctor.doctorexam.bean.RecordBean;
import com.kazeik.doctor.doctorexam.utils.ApiUtils;
import com.kazeik.doctor.doctorexam.utils.AppUtils;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by kazeik.chen on 2016/5/27 0027 15:02.
 * email:kazeik@163.com ,QQ:77132995
 */
public class ExamDB extends SQLiteOpenHelper{
    public static final String DB_NAME ="exam_db";
    private static final int VERSION = 1;
    public static final String TAB_EXAM = "examLoad";
    public ExamDB(Context context) {
        super(context, DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TAB_EXAM + " (id integer primary key autoincrement, path text,current integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void saveLoad(ContentValues cv){
        getReadableDatabase().insert(TAB_EXAM,null,cv);
    }

    public  ArrayList<RecordBean> loadRecord(){
        String sql = "select * from  "+ TAB_EXAM;
        Cursor cursor = getReadableDatabase().rawQuery(sql,null);
        ArrayList<RecordBean> beans = new ArrayList<>();
        while(cursor.moveToNext()){
            beans.add( getRecordItem(cursor));
        }
        return beans;
    }

    private RecordBean getRecordItem(Cursor cursor){
        RecordBean bean = new RecordBean();
        bean.current = cursor.getInt(cursor.getColumnIndex("current"));
        bean.path = cursor.getString(cursor.getColumnIndex("path"));
        if(!TextUtils.isEmpty(bean.path)){
            bean.name = bean.path.substring(bean.path.lastIndexOf("/")+1,bean.path.length());
        }
        AppUtils.logs(getClass(),bean.toString());
        return bean;
    }

    public RecordBean getCurrentPath(String path){
        Cursor cursor = getReadableDatabase().rawQuery("select path from "+ TAB_EXAM+" where path='"+path+"'",null);
        while(cursor.moveToNext()){
             return getRecordItem(cursor);
        }
        return null;
    }

}
