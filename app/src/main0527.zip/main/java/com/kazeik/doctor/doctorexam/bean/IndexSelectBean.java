package com.kazeik.doctor.doctorexam.bean;/**
 * 索引卡被选中的
 *
 * @author kazeik.chen , QQ:77132995,email:kazeik@163.com 2016 04 20 21:41
 */

/**
 * 索引卡被选中的
 * @author kazeik.chen , QQ:77132995,email:kazeik@163.com 2016 04 20 21:41
 */

public class IndexSelectBean {
    public int index;
    public boolean select;
}
