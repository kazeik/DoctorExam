package com.kazeik.doctor.doctorexam.activity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.kazeik.doctor.doctorexam.BaseActivity;
import com.kazeik.doctor.doctorexam.R;
import com.kazeik.doctor.doctorexam.bean.RecordBean;
import com.kazeik.doctor.doctorexam.db.ExamDB;

import java.util.ArrayList;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;
import it.angrydroids.ChangeCSSMenu;
import it.angrydroids.EpubManipulator;
import it.angrydroids.EpubNavigator;
import it.angrydroids.FileChooser;
import it.angrydroids.LanguageChooser;
import it.angrydroids.SetPanelSize;
import it.angrydroids.SplitPanel;
import nl.siegmann.epublib.domain.TOCReference;

public class BookReadActivity extends BaseActivity implements View.OnClickListener, AdapterView.OnItemClickListener {


    @Bind(R.id.tv_titleName)
    TextView tvTitleName;
    @Bind(R.id.tv_left)
    TextView tvLeft;

    SlidingMenu menu;

    String tempPath;

    //---------
    public EpubNavigator navigator;
    public int bookSelector;
    public int panelCount;
    public String[] settings;
    //----------

    ListView lsPageIndex;
    @Bind(R.id.tv_right)
    TextView tvRight;


    @Override
    public int initLayout() {
        return R.layout.activity_book_read;
    }

    @Override
    public void initData() {
        tempPath = getIntent().getStringExtra("path");
    }

    private void initEpub() {
        navigator = new EpubNavigator(1, this);

        panelCount = 0;
        settings = new String[8];

//        ArrayList<RecordBean> all = examDB.loadRecord();
//        if (all != null && !all.isEmpty()) {
//            Intent goToChooser = new Intent(this, FileChooser.class);
//            startActivityForResult(goToChooser, 0);
//            return;
//        }
        if (!TextUtils.isEmpty(tempPath)) {
//            RecordBean bean = examDB.getCurrentPath(tempPath);
//            if (null != bean) {
//                navigator.startPager(bean);
//            } else {
                openLoacationBook(tempPath);
//            }
            return;
        }
        // LOADSTATE
        SharedPreferences preferences = getPreferences(MODE_PRIVATE);
        loadState(preferences);
        navigator.loadViews(preferences);
        if (panelCount == 0) {
            bookSelector = 0;
            Intent goToChooser = new Intent(this, FileChooser.class);
            startActivityForResult(goToChooser, 0);
        } else {
            initLeftMenu(panelCount);
        }


    }

    @Override
    public void initWeight() {
        // configure the SlidingMenu
        menu = new SlidingMenu(this);
        menu.setMode(SlidingMenu.LEFT);
        // 设置触摸屏幕的模式
        menu.setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
        menu.setShadowWidthRes(R.dimen.dp_15);
//        menu.setShadowDrawable(R.drawable.shadow);

        // 设置滑动菜单视图的宽度
        menu.setBehindOffsetRes(R.dimen.dp_80);
        // 设置渐入渐出效果的值
        menu.setFadeDegree(0.35f);
        /**
         * SLIDING_WINDOW will include the Title/ActionBar in the content
         * section of the SlidingMenu, while SLIDING_CONTENT does not.
         */
        menu.attachToActivity(this, SlidingMenu.SLIDING_WINDOW);
        //为侧滑菜单设置布局
        menu.setMenu(R.layout.leftmenu);

        ImageView ivFont = (ImageView) menu.findViewById(R.id.iv_font);
        ivFont.setOnClickListener(this);
        menu.findViewById(R.id.iv_back).setOnClickListener(this);
        menu.findViewById(R.id.iv_bookMark).setOnClickListener(this);
        lsPageIndex = (ListView) menu.findViewById(R.id.ls_listView);
        lsPageIndex.setOnItemClickListener(this);

        tvLeft.setText("打开");
        tvLeft.setVisibility(View.VISIBLE);
        tvTitleName.setText("测试文本");

        tvRight.setVisibility(View.VISIBLE);
        tvRight.setText("添加书签");

        initEpub();

    }

    @Override
    public void onNetSuccess(String tag, String value) {

    }


    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @OnClick({R.id.tv_left, R.id.tv_right})
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_left:
//        if(menu.isMenuShowing()){
                menu.toggle();
//        }
                break;
            case R.id.iv_font:
                if (navigator.exactlyOneBookOpen() == true) {
                    DialogFragment newFragment = new ChangeCSSMenu();
                    newFragment.show(getFragmentManager(), "");
                    bookSelector = 0;
                }
                break;
            case R.id.iv_back:
                this.finish();
                break;
            case R.id.tv_right:
                break;
            case R.id.iv_bookMark:
                break;
        }
    }

    protected void onResume() {
        super.onResume();
        if (panelCount == 0) {
            SharedPreferences preferences = getPreferences(MODE_PRIVATE);
            navigator.loadViews(preferences);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences preferences = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        saveState(editor);
        editor.commit();
    }

    // load the selected book
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
//        if (panelCount == 0) {
//            SharedPreferences preferences = getPreferences(MODE_PRIVATE);
//            navigator.loadViews(preferences);
//        }

        if (resultCode == Activity.RESULT_OK) {
            RecordBean bean = examDB.getCurrentPath(tempPath);
            if (null != bean) {
                navigator.startPager(bean);
            } else {
                //获取选择文件返回的路径
                String path = data.getStringExtra(getString(R.string.bpath));
//            String path = sdcardUtils.getSDPath()+"/"+"7135.epub";
                openLoacationBook(path);
            }
        }
    }

    private void openLoacationBook(String path) {
        navigator.openBook(path, bookSelector);
        initLeftMenu(bookSelector);
    }

    /**
     * 初始化左边的菜单
     *
     * @param select
     */
    private void initLeftMenu(int select) {
        List<TOCReference> pageIndex = navigator.getTableList(select);
        if (null == pageIndex || pageIndex.isEmpty()) {
            return;
        }
        String[] str = new String[pageIndex.size()];
        for (int i = 0; i < pageIndex.size(); i++) {
            TOCReference reference = pageIndex.get(i);
            str[i] = reference.getTitle();
        }
        ArrayAdapter<String> myArrayAdapter =
                new ArrayAdapter<String>(this, android.R.layout.simple_expandable_list_item_1, str);
        lsPageIndex.setAdapter(myArrayAdapter);
    }


    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
//            case R.id.FirstEPUB:
//                bookSelector = 0;
//                Intent goToChooser1 = new Intent(this, FileChooser.class);
//                goToChooser1.putExtra(getString(R.string.second),
//                        getString(R.string.time));
//                startActivityForResult(goToChooser1, 0);
//                return true;
//
//            case R.id.SecondEPUB:
//                bookSelector = 1;
//                Intent goToChooser2 = new Intent(this, FileChooser.class);
//                goToChooser2.putExtra(getString(R.string.second),
//                        getString(R.string.time));
//                startActivityForResult(goToChooser2, 0);
//                return true;

            case R.id.Front:
                if (navigator.exactlyOneBookOpen() == true
                        || navigator.isParallelTextOn() == true)
                    chooseLanguage(0);
                return true;

            case R.id.FirstFront:
                chooseLanguage(0);
                return true;

            case R.id.SecondFront:
                if (navigator.exactlyOneBookOpen() == false)
                    chooseLanguage(1);
                else
                    errorMessage("只有一本书打开");
                return true;

            case R.id.PconS:
                try {
                    boolean yes = navigator.synchronizeView(1, 0);
                    if (!yes) {
                        errorMessage("只有一本书打开");
                    }
                } catch (Exception e) {
                    errorMessage("不能同步");
                }
                return true;

            case R.id.SconP:
                try {
                    boolean ok = navigator.synchronizeView(0, 1);
                    if (!ok) {
                        errorMessage("只有一本书打开");
                    }
                } catch (Exception e) {
                    errorMessage("不能同步");
                }
                return true;

            case R.id.Synchronize:

                boolean sync = navigator.flipSynchronizedReadingActive();
                if (!sync) {
                    errorMessage("只有一本书打开");
                }
                return true;

            case R.id.Metadata:
                if (navigator.exactlyOneBookOpen() == true
                        || navigator.isParallelTextOn() == true) {
                    navigator.displayMetadata(0);
                } else {
                }
                return true;

            case R.id.meta1:
                if (!navigator.displayMetadata(0))
                    errorMessage("元数据没有找到");
                return true;

            case R.id.meta2:
                if (!navigator.displayMetadata(1))
                    errorMessage("元数据没有找到");
                return true;

            case R.id.tableOfContents:
                if (navigator.exactlyOneBookOpen() == true
                        || navigator.isParallelTextOn() == true)
                    navigator.displayTOC(0);
                return true;

            case R.id.toc1:
                if (!navigator.displayTOC(0))
                    errorMessage("目录未找到");
                return true;
            case R.id.toc2:
                if (navigator.displayTOC(1))
                    errorMessage("目录未找到");
                return true;
            case R.id.changeSize:
                try {
                    DialogFragment newFragment = new SetPanelSize();
                    newFragment.show(getFragmentManager(), "");
                } catch (Exception e) {
                    errorMessage("不能改变大小");
                }
                return true;
            case R.id.Style: // work in progress...
                try {
                    if (navigator.exactlyOneBookOpen() == true) {
                        DialogFragment newFragment = new ChangeCSSMenu();
                        newFragment.show(getFragmentManager(), "");
                        bookSelector = 0;
                    }
                } catch (Exception e) {
                    errorMessage("不能改变风格");
                }
                return true;

            case R.id.StyleBook1:
                try {
                    DialogFragment newFragment = new ChangeCSSMenu();
                    newFragment.show(getFragmentManager(), "");
                    bookSelector = 0;
                } catch (Exception e) {
                    errorMessage("不能改变风格");
                }
                return true;

            case R.id.StyleBook2:
                try {
                    DialogFragment newFragment = new ChangeCSSMenu();
                    newFragment.show(getFragmentManager(), "");
                    bookSelector = 1;
                } catch (Exception e) {
                    errorMessage("不能改变风格");
                }
                return true;

			/*
             * case R.id.SyncScroll: syncScrollActivated = !syncScrollActivated;
			 * return true;
			 */

            case R.id.audio:
                if (navigator.exactlyOneBookOpen() == true)
                    if (!navigator.extractAudio(0))
                        errorMessage(getString(R.string.no_audio));
                return true;
            case R.id.firstAudio:
                if (!navigator.extractAudio(0))
                    errorMessage(getString(R.string.no_audio));
                return true;
            case R.id.secondAudio:
                if (!navigator.extractAudio(1))
                    errorMessage(getString(R.string.no_audio));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // ----
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void addPanel(SplitPanel p) {
        FragmentTransaction fragmentTransaction = getFragmentManager()
                .beginTransaction();
        fragmentTransaction.add(R.id.MainLayout, p, p.getTag());
        fragmentTransaction.commit();

        panelCount++;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    public void attachPanel(SplitPanel p) {
        FragmentTransaction fragmentTransaction = getFragmentManager()
                .beginTransaction();
        fragmentTransaction.attach(p);
        fragmentTransaction.commit();

        panelCount++;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
    public void detachPanel(SplitPanel p) {
        FragmentTransaction fragmentTransaction = getFragmentManager()
                .beginTransaction();
        fragmentTransaction.detach(p);
        fragmentTransaction.commit();

        panelCount--;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void removePanelWithoutClosing(SplitPanel p) {
        FragmentTransaction fragmentTransaction = getFragmentManager()
                .beginTransaction();
        fragmentTransaction.remove(p);
        fragmentTransaction.commit();

        panelCount--;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void removePanel(SplitPanel p) {
        FragmentTransaction fragmentTransaction = getFragmentManager()
                .beginTransaction();
        fragmentTransaction.remove(p);
        fragmentTransaction.commit();

        panelCount--;
        if (panelCount <= 0)
            finish();
    }

    // ----

    // ---- Language Selection
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    public void chooseLanguage(int book) {

        String[] languages;
        languages = navigator.getLanguagesBook(book);
        if (languages.length == 2)
            refreshLanguages(book, 0, 1);
        else if (languages.length > 0) {
            Bundle bundle = new Bundle();
            bundle.putInt(getString(R.string.tome), book);
            bundle.putStringArray(getString(R.string.lang), languages);

            LanguageChooser langChooser = new LanguageChooser();
            langChooser.setArguments(bundle);
            langChooser.show(getFragmentManager(), "");
        } else {
            errorMessage(getString(R.string.error_noOtherLanguages));
        }
    }

    public void refreshLanguages(int book, int first, int second) {
        navigator.parallelText(book, first, second);
    }

    // ----

    // ---- Change Style
    public void setCSS() {
        navigator.changeCSS(bookSelector, settings);
    }

    public void setBackColor(String my_backColor) {
        settings[1] = my_backColor;
    }

    public void setColor(String my_color) {
        settings[0] = my_color;
    }

    public void setFontType(String my_fontFamily) {
        settings[2] = my_fontFamily;
    }

    public void setFontSize(String my_fontSize) {
        settings[3] = my_fontSize;
    }

    public void setLineHeight(String my_lineHeight) {
        if (my_lineHeight != null)
            settings[4] = my_lineHeight;
    }

    public void setAlign(String my_Align) {
        settings[5] = my_Align;
    }

    public void setMarginLeft(String mLeft) {
        settings[6] = mLeft;
    }

    public void setMarginRight(String mRight) {
        settings[7] = mRight;
    }

    // ----

    // change the views size, changing the weight
    public void changeViewsSize(float weight) {
        navigator.changeViewsSize(weight);
    }

    public int getHeight() {
        LinearLayout main = (LinearLayout) findViewById(R.id.MainLayout);
        return main.getMeasuredHeight();
    }

    public int getWidth() {
        LinearLayout main = (LinearLayout) findViewById(R.id.MainLayout);
        return main.getWidth();
    }

    // Save/Load State
    protected void saveState(SharedPreferences.Editor editor) {
        navigator.saveState(editor);
    }

    protected void loadState(SharedPreferences preferences) {
        if (!navigator.loadState(preferences))
            errorMessage(getString(R.string.error_cannotLoadState));
    }

    public void errorMessage(String message) {
        Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, message, Toast.LENGTH_SHORT);
        toast.show();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        List<TOCReference> pageIndex = navigator.getTableList(bookSelector);
        String path = "file://" + EpubManipulator.location + bookSelector + "/"
                + navigator.getBooks()[bookSelector].getPathOPF() + "/" + pageIndex.get(position).getCompleteHref();
        navigator.setBookPage(path, bookSelector);
        if (menu.isMenuShowing()) {
            menu.toggle();
        }
    }

}
