package com.kazeik.doctor.doctorexam.activity;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.kazeik.doctor.doctorexam.BaseActivity;
import com.kazeik.doctor.doctorexam.R;
import com.kazeik.doctor.doctorexam.bean.LessonInfoBean;
import com.kazeik.doctor.doctorexam.bean.LessonItemBean;
import com.kazeik.doctor.doctorexam.utils.ApiUtils;
import com.kazeik.doctor.doctorexam.utils.AppUtils;
import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.HttpHandler;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseInfo;
import com.lidroid.xutils.http.callback.RequestCallBack;
import com.sevenheaven.segmentcontrol.SegmentControl;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class LessonInfoActivity extends BaseActivity implements SegmentControl.OnSegmentControlClickListener {

    @Bind(R.id.tv_titleName)
    TextView tvTitleName;
    @Bind(R.id.tv_left)
    TextView tvLeft;
    @Bind(R.id.iv_icon)
    ImageView ivIcon;
    @Bind(R.id.tv_lessonName)
    TextView tvLessonName;
    @Bind(R.id.tv_lessonBody)
    TextView tvLessonBody;
    @Bind(R.id.sv_ment)
    SegmentControl svMent;

    LessonItemBean lessonBean;
    @Bind(R.id.tv_item1)
    TextView tvItem1;
    @Bind(R.id.tv_item2)
    TextView tvItem2;
    @Bind(R.id.tv_item3)
    TextView tvItem3;
    @Bind(R.id.tv_item4)
    TextView tvItem4;

    @Bind(R.id.tv_book_item1)
    TextView tvBookItem1;
    @Bind(R.id.tv_book_item2)
    TextView tvBookItem2;
    @Bind(R.id.tv_book_item3)
    TextView tvBookItem3;
    @Bind(R.id.tv_book_item4)
    TextView tvBookItem4;

    @Bind(R.id.sl_lessonView)
    ScrollView slLessonView;
    @Bind(R.id.ll_view)
    LinearLayout ll_view;
    LessonInfoBean infoBean;

    boolean isMylesson;

    HttpHandler httpHandler;
    @Bind(R.id.ll_page1)
    LinearLayout llPage1;
    @Bind(R.id.ll_page_view1)
    LinearLayout llPageView1;
    @Bind(R.id.ll_page2)
    LinearLayout llPage2;
    @Bind(R.id.ll_page_view2)
    LinearLayout llPageView2;
    @Bind(R.id.ll_page3)
    LinearLayout llPage3;
    @Bind(R.id.ll_page_view3)
    LinearLayout llPageView3;

    @Override
    public int initLayout() {
        return R.layout.activity_lesson_info;
    }

    @Override
    public void initData() {
        lessonBean = (LessonItemBean) getIntent().getSerializableExtra("lesson");
        isMylesson = getIntent().getBooleanExtra("myLesson", false);
    }

    private void initView(int index) {
        switch (index) {
            case 0:
                llPageView1.setVisibility(View.VISIBLE);
                llPageView2.setVisibility(View.GONE);
                llPageView3.setVisibility(View.GONE);

                initPage1();
                break;
            case 1:
                llPageView1.setVisibility(View.GONE);
                llPageView2.setVisibility(View.VISIBLE);
                llPageView3.setVisibility(View.GONE);

                initPage2();
                break;
            case 2:
                llPageView1.setVisibility(View.GONE);
                llPageView2.setVisibility(View.GONE);
                llPageView3.setVisibility(View.VISIBLE);

                initPage3();
                break;
        }
    }

    private void initPage1() {
        if (null == infoBean) {
            return;
        }
        tvItem1.setText("课件名");
        tvItem2.setText("课时");
        tvItem3.setText("学科");
        tvItem4.setText("操作");
        llPage1.removeAllViews();
        for (int i = 0; i < infoBean.re_msg.courseware.size(); i++) {
            final LessonInfoBean.CourseWareItemBean itemBean = infoBean.re_msg.courseware.get(i);
            View view = LayoutInflater.from(this).inflate(R.layout.layout_lesson_item, null);
            llPage1.addView(view);

            TextView tvSubItem1 = (TextView) view.findViewById(R.id.tv_item1);
            TextView tvSubItem2 = (TextView) view.findViewById(R.id.tv_item2);
            TextView tvSubItem3 = (TextView) view.findViewById(R.id.tv_item3);
            final TextView tvSubItem4 = (TextView) view.findViewById(R.id.tv_item4);

            tvSubItem1.setText(itemBean.title);
            tvSubItem2.setText(itemBean.course_class_hour);
            tvSubItem3.setText(itemBean.key_course_major_id);

            if (!isMylesson) {
                if (lessonBean.is_buy == 2) {
                    tvItem4.setVisibility(View.GONE);
                    tvSubItem4.setVisibility(View.GONE);
                } else {
                    tvItem4.setVisibility(View.VISIBLE);
                    tvSubItem4.setVisibility(View.VISIBLE);
                }
            }

            final File file = new File(sdcardUtils.getSDPath() + "/DoctorExam/video/" + itemBean.title + "_" + itemBean.id + ".mp4");
            if (file.exists()) {
                tvSubItem4.setText("开始学习");
                tvSubItem4.setTextColor(Color.parseColor("#32cba8"));
            } else {
                tvSubItem4.setText("下载");
                tvSubItem4.setTextColor(Color.parseColor("#e97525"));
            }

            tvSubItem4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (file.exists())
                        startVideo(file.getPath());
                    else
                        downFile(true, itemBean.encryption, itemBean.title + "_" + itemBean.id + ".mp4", tvSubItem4);
                }
            });
        }
    }

    private void initPage2() {
        if (null == infoBean) {
            return;
        }

        tvBookItem1.setText("课件名");
        tvBookItem2.setText("课时");
        tvBookItem3.setText("学科");
//        tvBookItem4.setText("所属分类");

        llPage2.removeAllViews();
        for (int i = 0; i < infoBean.re_msg.ebook.size(); i++) {
            final LessonInfoBean.EbookItemBean itemBean = infoBean.re_msg.ebook.get(i);
            View view = LayoutInflater.from(this).inflate(R.layout.layout_lesson_item, null);
            llPage2.addView(view);
            TextView tvSubItem1 = (TextView) view.findViewById(R.id.tv_item1);
            TextView tvSubItem2 = (TextView) view.findViewById(R.id.tv_item2);
            TextView tvSubItem3 = (TextView) view.findViewById(R.id.tv_item3);
            final TextView tvSubItem4 = (TextView) view.findViewById(R.id.tv_item4);

            if (!isMylesson) {
                if (lessonBean.is_buy == 2) {
                    tvBookItem4.setVisibility(View.GONE);
                    tvSubItem4.setVisibility(View.GONE);
                } else {
                    tvBookItem4.setVisibility(View.VISIBLE);
                    tvBookItem4.setText("操作");
                    tvSubItem4.setVisibility(View.VISIBLE);
                }
            } else {
                tvBookItem4.setVisibility(View.VISIBLE);
                tvBookItem4.setText("操作");
            }

            tvSubItem1.setText(itemBean.name);
            tvSubItem2.setText(itemBean.professional_field);
            tvSubItem3.setText(itemBean.key_pro_field);
            tvSubItem4.setText("下载");
            tvSubItem4.setTextColor(Color.parseColor("#e97525"));

            tvItem2.setVisibility(View.VISIBLE);
            tvSubItem2.setVisibility(View.VISIBLE);

            final File file = new File(sdcardUtils.getSDPath() + "/DoctorExam/ebook/" + itemBean.name + "_" + itemBean.id + ".epub");
            if (file.exists()) {
                tvSubItem4.setText("开始学习");
                tvSubItem4.setTextColor(Color.parseColor("#32cba8"));
            } else {
                tvSubItem4.setText("下载");
                tvSubItem4.setTextColor(Color.parseColor("#e97525"));
            }

            tvSubItem4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (file.exists()) {
                        Intent intt = new Intent(LessonInfoActivity.this,BookReadActivity.class);
                        intt.putExtra("path",file.getPath());
                        startOtherView(intt);
                    } else {
                        downFile(false, itemBean.encryption, itemBean.name + "_" + itemBean.id + ".epub", tvSubItem4);
                    }
                }
            });
        }
    }

    private void startVideo(String path) {
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("oneshot", 0);
        intent.putExtra("configchange", 0);
        Uri uri = Uri.fromFile(new File(path));
        intent.setDataAndType(uri, "video/*");
        try {
            startActivity(intent);
        } catch (Exception ex) {
            AppUtils.showToast(LessonInfoActivity.this, "未找到合适的播放器");
        }
    }

    private void downFile(final boolean video, String encryption, String name, final TextView tvShow) {
        final String path = sdcardUtils.getSDPath() + "/DoctorExam/" + (video ? "video/" : "ebook/") + name;
        File file = new File(path);
        if (file != null && file.exists()) {
            file.delete();
        }
        String url = ApiUtils.baseUrl + (video ? ApiUtils.videoDownload : ApiUtils.ebookDownload) + "?encryption=" + encryption + "&system_id=" + ApiUtils.userInfoBean.re_msg.sys + "&user_id=" + ApiUtils.userInfoBean.re_msg.id + "&password=" + ApiUtils.userInfoBean.re_msg.password;
        AppUtils.logs(getClass(), url + "\n" + path);
        HttpUtils httpUtils = new HttpUtils();
        RequestParams params = new RequestParams();
        params.addHeader("Accept-Length", "identity");
        params.setContentType("application/octet-stream");
        httpHandler = httpUtils.download(url, path, params, new RequestCallBack<File>() {
            @Override
            public void onSuccess(ResponseInfo<File> responseInfo) {
//                Header[] headers = responseInfo.getAllHeaders();
//                for (int i = 0; i < headers.length; i++) {
//                    AppUtils.logs("tag", headers[i].getName() + " | " + headers[i].getValue() + " | " + responseInfo.contentLength);
//                }
                tvShow.setText("打开");
                if (video) {
                    startVideo(path);
                } else {
                    Intent intt = new Intent(LessonInfoActivity.this,BookReadActivity.class);
                    intt.putExtra("path",path);
                    startOtherView(intt);
                }
            }

            @Override
            public void onFailure(HttpException error, String msg) {
                AppUtils.logs(getClass(), msg);
                AppUtils.showToast(LessonInfoActivity.this, "下载出错");
            }

            @Override
            public void onLoading(long total, long current, boolean isUploading) {
                super.onLoading(total, current, isUploading);
                AppUtils.logs(getClass(), total + " | " + current);
//                tvShow.setText(current + "/" + total);
                tvShow.setText(current + "");
            }
        });
    }

    private void initPage3() {
        if (null == infoBean) {
            return;
        }
        llPage3.removeAllViews();
        View topView = null;
        if (isMylesson) {
            topView = LayoutInflater.from(this).inflate(R.layout.layout_lesson_mock_item, null);
            TextView tvSubItem1 = (TextView) topView.findViewById(R.id.tv_mock_item1);
            TextView tvSubItem4 = (TextView) topView.findViewById(R.id.tv_mock_item4);

            tvSubItem1.setText("考卷标题");
            tvSubItem4.setText("操作");
        } else {
            topView = LayoutInflater.from(this).inflate(R.layout.layout_lesson_item, null);
            TextView tvTopItem1 = (TextView) topView.findViewById(R.id.tv_item1);
            TextView tvTopItem2 = (TextView) topView.findViewById(R.id.tv_item2);
            TextView tvTopItem3 = (TextView) topView.findViewById(R.id.tv_item3);
            TextView tvTopItem4 = (TextView) topView.findViewById(R.id.tv_item4);


//            tvSubItem1.setVisibility(View.GONE);
            tvTopItem1.setText("考卷标题");
            tvTopItem2.setText("考卷级别");
            tvTopItem3.setText("课时");
            tvTopItem4.setText("操作");

            if (lessonBean.is_buy != 1) {
                tvTopItem3.setVisibility(View.GONE);
                tvTopItem4.setVisibility(View.GONE);
            }
        }
        llPage3.addView(topView);
        for (int i = 0; i < infoBean.re_msg.paperItemBeans.size(); i++) {
            LessonInfoBean.PaperItemBean itemBean = infoBean.re_msg.paperItemBeans.get(i);
            View view = null;
            TextView tvSubItem2 = null;
            TextView tvSubItem3 = null;
            TextView tvSubItem1 = null;
            TextView tvSubItem4 = null;
            if (isMylesson) {
                view = LayoutInflater.from(this).inflate(R.layout.layout_lesson_mock_item, null);
                tvSubItem1 = (TextView) view.findViewById(R.id.tv_mock_item1);
                tvSubItem4 = (TextView) view.findViewById(R.id.tv_mock_item4);
            } else {
                view = LayoutInflater.from(this).inflate(R.layout.layout_lesson_item, null);
                tvSubItem2 = (TextView) view.findViewById(R.id.tv_item2);
                tvSubItem3 = (TextView) view.findViewById(R.id.tv_item3);
                tvSubItem1 = (TextView) view.findViewById(R.id.tv_item1);
                tvSubItem4 = (TextView) view.findViewById(R.id.tv_item4);

                if (!isMylesson) {
                    if (lessonBean.is_buy == 2) {
                        tvItem4.setVisibility(View.GONE);
                        tvSubItem4.setVisibility(View.GONE);
                    } else {
                        tvItem4.setVisibility(View.VISIBLE);
                        tvSubItem4.setVisibility(View.VISIBLE);
                    }
                }

                tvItem2.setVisibility(View.GONE);
//                tvSubItem2.setVisibility(View.GONE);
            }
            llPage3.addView(view);
            tvSubItem1.setText(itemBean.caption);
            if (!isMylesson) {
                if (lessonBean.is_buy == 1) {
                    tvSubItem2.setVisibility(View.VISIBLE);
                    tvSubItem2.setText(itemBean.key_grade);
                    tvSubItem3.setText(itemBean.category);
                    tvSubItem4.setText("");
                }else {
                    tvSubItem2.setVisibility(View.GONE);
                    tvSubItem2.setText(itemBean.category);
                    tvSubItem3.setText(itemBean.key_grade);
                    tvSubItem4.setText("");
                }

            }
        }
    }

    @Override
    public void initWeight() {
        tvTitleName.setText(lessonBean.title);
        tvLeft.setText(R.string.back);
        tvLeft.setVisibility(View.VISIBLE);

        utils.display(ivIcon, "http://" + lessonBean.pic);

        tvLessonName.setText(lessonBean.title);
        tvLessonBody.setText(lessonBean.describe);
        initView(0);
        svMent.setOnSegmentControlClickListener(this);

        ll_view.setBackgroundColor(Color.parseColor("#f1f1f1"));

        RequestParams params = getParams();
        params.addBodyParameter("course_id", lessonBean.id);
        requestNetData(params, ApiUtils.lessonDetail);
    }

    @Override
    public void onNetSuccess(String tag, String value) {
        if (tag.equals(ApiUtils.lessonDetail)) {
            infoBean = new LessonInfoBean();
            infoBean.re_msg = new LessonInfoBean.ReMsgBean();
            infoBean.re_msg.courseware = new ArrayList<>();
            infoBean.re_msg.paperItemBeans = new ArrayList<>();
            infoBean.re_msg.ebook = new ArrayList<>();
            try {
                JSONObject root = new JSONObject(value);
                JSONObject msgObj = root.optJSONObject("re_msg");
                //----------------------
                JSONObject courseObj = msgObj.optJSONObject("courseware");
                Iterator courseObjKey = courseObj.keys();
                while (courseObjKey.hasNext()) {
                    String key = courseObjKey.next().toString();
                    JSONArray courseArr = courseObj.optJSONArray(key);
                    for (int i = 0; i < courseArr.length(); i++) {
                        JSONObject itemObj = courseArr.optJSONObject(i);
                        LessonInfoBean.CourseWareItemBean itemBean = gson.fromJson(itemObj.toString(), LessonInfoBean.CourseWareItemBean.class);
                        infoBean.re_msg.courseware.add(itemBean);
                    }
                }
                //------------------------
                JSONObject paperObj = msgObj.optJSONObject("paper");
                Iterator paperKey = paperObj.keys();
                while (paperKey.hasNext()) {
                    String key = paperKey.next().toString();
                    JSONArray courseArr = paperObj.optJSONArray(key);
                    for (int i = 0; i < courseArr.length(); i++) {
                        JSONObject itemObj = courseArr.optJSONObject(i);
                        LessonInfoBean.PaperItemBean itemBean = gson.fromJson(itemObj.toString(), LessonInfoBean.PaperItemBean.class);
                        infoBean.re_msg.paperItemBeans.add(itemBean);
                    }
                }
                //------------------------
                JSONObject ebookObj = msgObj.optJSONObject("ebook");
                Iterator ebookKey = ebookObj.keys();
                while (ebookKey.hasNext()) {
                    String key = ebookKey.next().toString();
                    JSONArray courseArr = ebookObj.optJSONArray(key);
                    for (int i = 0; i < courseArr.length(); i++) {
                        JSONObject itemObj = courseArr.optJSONObject(i);
                        LessonInfoBean.EbookItemBean itemBean = gson.fromJson(itemObj.toString(), LessonInfoBean.EbookItemBean.class);
                        infoBean.re_msg.ebook.add(itemBean);
                    }
                }
                //------------------------
            } catch (JSONException e) {
                e.printStackTrace();
            }
            initView(0);
        } else if (tag.equals(ApiUtils.ebookDownload)) {

        } else if (tag.equals(ApiUtils.videoDownload)) {

        }
    }


    @OnClick(R.id.tv_left)
    public void onClick() {
        this.finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (null != httpHandler) {
            httpHandler.cancel();
        }
    }

    @Override
    public void onSegmentControlClick(int index) {
        initView(index);
    }
}
