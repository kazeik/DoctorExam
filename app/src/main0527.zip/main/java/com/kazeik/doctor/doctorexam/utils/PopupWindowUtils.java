//package com.kazeik.databaseslib.utils;
//
//import android.app.Activity;
//import android.content.Context;
//import android.graphics.Color;
//import android.graphics.drawable.BitmapDrawable;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.WindowManager;
//import android.widget.ArrayAdapter;
//import android.widget.ListView;
//import android.widget.PopupWindow;
//
//import com.kazeik.databaseslib.databaseslib.R;
//
///**
// * @deprecated
// * Created by kazeik.chen on 2016/3/10 0010 11:48.
// * email:kazeik@163.com ,QQ:77132995
// */
//public class PopupWindowUtils {
////    static PopupWindow popupWindow;
//
//
//
////    private void initPopWindow(Activity activity,View parent,View dropView){
////        ListView listView = null;
////        if(popupWindow == null) {
////            View contentView = LayoutInflater.from(activity).inflate(R.layout.view_list, null);
////            contentView.setBackgroundColor(Color.BLUE);
////            popupWindow = new PopupWindow(parent, 200, 700);
////            popupWindow.setContentView(contentView);
////            listView = (ListView) contentView.findViewById(R.id.list);
////        }
////        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, name);
////        listView.setAdapter(adapter);
////
////        popupWindow.setFocusable(true);
////        popupWindow.showAsDropDown(dropView);
////    }
//
//
//
////    public static void cancelPopupWindow() {
////        if (null != popupWindow) {
////            popupWindow.dismiss();
////            popupWindow = null;
////        }
////    }
//}
